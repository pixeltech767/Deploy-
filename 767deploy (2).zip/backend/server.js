
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => res.send('767Deploy Backend Running'));

app.post('/import/replit', async (req, res) => {
  const { url } = req.body;
  if (!url || !url.includes("replit.com")) {
    return res.status(400).json({ error: "Invalid Replit URL" });
  }

  // Extract project slug
  const parts = url.split('/');
  const projectName = parts[parts.length - 1];
  const projectPath = path.join(__dirname, 'uploads', projectName);

  if (!fs.existsSync(path.join(__dirname, 'uploads'))) {
    fs.mkdirSync(path.join(__dirname, 'uploads'));
  }

  // Simulated: Replit doesn't offer raw zip download, so in real deployment, use Puppeteer or CLI
  fs.mkdirSync(projectPath, { recursive: true });
  fs.writeFileSync(path.join(projectPath, 'README.txt'), `Simulated import for: ${url}`);

  // Analyze project type (just stub logic here)
  let type = "web";
  if (projectName.toLowerCase().includes("apk") || projectName.toLowerCase().includes("android")) {
    type = "apk";
  }

  const downloadUrl = \`https://767deploy.app/downloads/\${projectName}.\${type === "apk" ? "apk" : "zip"}\`;

  return res.json({
    status: "success",
    type,
    message: \`\${type === "apk" ? "Android" : "Web"} project ready for build/deploy.\`,
    downloadUrl
  });
});

app.post('/import/github', (req, res) => {
  const { githubUrl } = req.body;
  res.json({ message: \`Imported project from GitHub: \${githubUrl}\` });
});

app.listen(PORT, () => console.log(\`767Deploy backend listening on port \${PORT}\`));
