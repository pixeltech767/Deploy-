
# 767Deploy

Web-based platform for deploying web apps and APKs from Replit or GitHub.

## Setup

1. Clone or unzip this project
2. Run: `docker-compose up --build`

## Services

- **Frontend** – React/Vite UI (under development)
- **Backend** – Express API
- **APK Builder** – Docker image to compile Android APKs
- **Web Deployer** – Static site deployer

## Example API Usage

POST `/import/replit`
```json
{
  "replitUrl": "https://replit.com/@username/project"
}
```

POST `/import/github`
```json
{
  "githubUrl": "https://github.com/username/repo"
}
```
